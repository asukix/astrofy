// Reading a product from the open page, and building the Surpriser link from it.
//
// Both functions must stay self-contained (no outside variables, no imports): the popup hands
// `surpriserExtract` to chrome.scripting.executeScript, which serializes the function into the page,
// and the bookmarklet build copies their source text. Order of the sources (ProjectInfo.md 3/C):
// JSON-LD → microdata / product meta → Open Graph → <h1> / page title.

/**
 * @returns {{
 *   name: string, priceHuf: number | null, foreignCurrency: string, description: string,
 *   imageUrl: string, productUrl: string, missing: string[], sources: string[]
 * }}
 */
export function surpriserExtract() {
  const LIMIT = { name: 200, description: 300, url: 2000 };
  const TRACKING = /^(utm_.*|gad_.*|gclid|gbraid|wbraid|dclid|fbclid|yclid|msclkid|mc_cid|mc_eid|_ga|_gl|igshid|srsltid|spm|_hsenc|_hsmi|mkt_tok)$/i;
  const sources = new Set();

  /** Plain text: HTML entities and tags removed, whitespace collapsed. */
  const plain = (value) => {
    if (value == null) return "";
    let s = Array.isArray(value) ? value.find((v) => typeof v === "string") ?? "" : String(value);
    if (/[<&]/.test(s)) s = new DOMParser().parseFromString(s, "text/html").documentElement.textContent ?? "";
    return s.replace(/\s+/g, " ").trim();
  };

  /** Absolute http(s) URL, or "". */
  const absolute = (value) => {
    const s = plain(value);
    if (!s || s.startsWith("data:")) return "";
    try {
      const url = new URL(s, location.href);
      return (url.protocol === "http:" || url.protocol === "https:") && url.href.length <= LIMIT.url ? url.href : "";
    } catch {
      return "";
    }
  };

  /** "24990.00", 24990, "24 990 Ft", "24.990,-" → 24990; null when unclear. */
  const parsePrice = (value) => {
    if (typeof value === "number") return Number.isFinite(value) && value > 0 ? Math.round(value) : null;
    let s = plain(value)
      .replace(/[\s  ]/g, "")
      .replace(/(ft|huf)\.?$/i, "")
      .replace(/[,.]-+$/, "")
      .replace(/-+$/, "");
    let n = NaN;
    if (/^\d{1,3}([.,]\d{3})+$/.test(s)) n = Number(s.replace(/[.,]/g, ""));
    else if (/^\d{1,3}(\.\d{3})+,\d{1,2}$/.test(s)) n = Number(s.replace(/\./g, "").replace(",", "."));
    else if (/^\d{1,3}(,\d{3})+\.\d{1,2}$/.test(s)) n = Number(s.replace(/,/g, ""));
    else if (/^\d+([.,]\d{1,2})?$/.test(s)) n = Number(s.replace(",", "."));
    const rounded = Math.round(n);
    return rounded >= 1 && rounded <= 100_000_000 ? rounded : null;
  };

  const meta = (...keys) => {
    for (const key of keys) {
      const el = document.querySelector(`meta[property="${key}"], meta[name="${key}"], meta[itemprop="${key}"]`);
      const content = el?.getAttribute("content");
      if (content && content.trim()) return content.trim();
    }
    return "";
  };

  const firstImage = (value) => {
    if (!value) return "";
    if (Array.isArray(value)) {
      for (const item of value) {
        const url = firstImage(item);
        if (url) return url;
      }
      return "";
    }
    if (typeof value === "object") return absolute(value.url ?? value.contentUrl ?? value["@id"]);
    return absolute(value);
  };

  // ---------- 1. JSON-LD ----------
  const isProduct = (node) => {
    const type = node?.["@type"];
    const types = Array.isArray(type) ? type : [type];
    return types.some((t) => typeof t === "string" && /(^|[/#:])(Product|ProductGroup|IndividualProduct|ProductModel)$/i.test(t));
  };
  const products = [];
  const walk = (node, depth) => {
    if (!node || typeof node !== "object" || depth > 6) return;
    if (Array.isArray(node)) return node.forEach((n) => walk(n, depth + 1));
    if (isProduct(node)) products.push(node);
    for (const key of ["@graph", "mainEntity", "mainEntityOfPage", "itemListElement", "item"]) walk(node[key], depth + 1);
  };
  for (const script of document.querySelectorAll('script[type="application/ld+json"]')) {
    const raw = script.textContent ?? "";
    try {
      walk(JSON.parse(raw), 0);
    } catch {
      try {
        // Some shops leave raw line breaks or control characters inside strings.
        walk(JSON.parse(raw.replace(/[\u0000-\u001f]+/g, " ")), 0);
      } catch {
        /* unreadable block: skip */
      }
    }
  }

  /** Offers of a product: Offer, AggregateOffer, arrays, priceSpecification, a ProductGroup's variants. */
  const offersOf = (product) => {
    const out = [];
    const add = (offer) => {
      if (!offer) return;
      if (Array.isArray(offer)) return offer.forEach(add);
      if (typeof offer !== "object") return;
      if (offer.offers) add(offer.offers);
      const spec = Array.isArray(offer.priceSpecification) ? offer.priceSpecification[0] : offer.priceSpecification;
      out.push({
        price: offer.price ?? offer.lowPrice ?? spec?.price ?? null,
        currency: plain(offer.priceCurrency ?? spec?.priceCurrency ?? "").toUpperCase(),
      });
    };
    add(product.offers);
    (Array.isArray(product.hasVariant) ? product.hasVariant : []).forEach((v) => add(v?.offers));
    return out.filter((o) => o.price != null && o.price !== "");
  };

  // Several "products" may be on a page: review widgets (Trustindex and the like) add one for the
  // shop itself, with its logo, rating text and home page. The real product is the one with a price
  // and this page's address; review-only nodes pointing elsewhere are dropped.
  const samePage = (value) => {
    const url = absolute(value);
    if (!url) return null;
    const a = new URL(url);
    return a.hostname.replace(/^www\./, "") === location.hostname.replace(/^www\./, "") && a.pathname.replace(/\/$/, "") === location.pathname.replace(/\/$/, "");
  };
  const scored = products
    .map((p) => {
      const hasOffer = offersOf(p).length > 0;
      const here = samePage(p.url ?? p["@id"]);
      const pointsHome = (() => {
        const url = absolute(p.url);
        return !!url && new URL(url).pathname.replace(/\/$/, "") === "" && location.pathname.replace(/\/$/, "") !== "";
      })();
      const reviewsOnly = !hasOffer && !!(p.aggregateRating || p.review);
      let score = 0;
      if (hasOffer) score += 5;
      if (here === true) score += 4;
      if (p.sku || p.gtin || p.gtin13 || p.gtin8 || p.mpn || p.productID) score += 2;
      if (plain(p.name)) score += 1;
      if (pointsHome) score -= 6;
      if (reviewsOnly) score -= 6;
      return { p, score, drop: (pointsHome || reviewsOnly) && !hasOffer };
    })
    .filter((c) => !c.drop)
    .sort((a, b) => b.score - a.score);
  const product = scored[0]?.p ?? null;
  let name = "";
  let description = "";
  let imageUrl = "";
  let productUrlFromData = "";
  let price = null; // { value, currency, source }

  if (product) {
    name = plain(product.name);
    description = plain(product.description);
    imageUrl = firstImage(product.image);
    productUrlFromData = absolute(product.url);
    const offers = offersOf(product);
    const offer = offers.find((o) => o.currency === "HUF") ?? offers[0];
    if (offer) price = { value: offer.price, currency: offer.currency, source: "jsonld" };
    if (name || description || imageUrl || offer) sources.add("jsonld");
  }

  // ---------- 2. microdata and product meta tags ----------
  const scope = document.querySelector('[itemscope][itemtype*="schema.org/Product" i]');
  if (scope) {
    const prop = (key) => {
      const el = scope.querySelector(`[itemprop="${key}"]`);
      if (!el) return "";
      return (
        el.getAttribute("content") ?? el.getAttribute("src") ?? el.getAttribute("href") ?? el.getAttribute("value") ?? el.textContent ?? ""
      ).trim();
    };
    let used = false;
    if (!name && prop("name")) (name = plain(prop("name"))), (used = true);
    if (!description && prop("description")) (description = plain(prop("description"))), (used = true);
    if (!imageUrl && prop("image")) (imageUrl = absolute(prop("image"))), (used = !!imageUrl || used);
    if (!price && (prop("price") || prop("lowPrice"))) {
      price = { value: prop("price") || prop("lowPrice"), currency: prop("priceCurrency").toUpperCase(), source: "microdata" };
      used = true;
    }
    if (used) sources.add("microdata");
  }
  if (!price) {
    const amount = meta("product:price:amount", "og:price:amount", "price");
    if (amount) {
      price = { value: amount, currency: meta("product:price:currency", "og:price:currency", "priceCurrency").toUpperCase(), source: "meta" };
      sources.add("meta");
    }
  }

  // ---------- 3. Open Graph (and Twitter cards) ----------
  const h1 = plain(document.querySelector("h1")?.textContent);
  if (!name && meta("og:title")) {
    const og = plain(meta("og:title"));
    // Some shops cut og:title short ("… Treecko N"); the page heading has it whole.
    if (h1 && h1.length <= LIMIT.name && h1.length > og.length && h1.startsWith(og)) (name = h1), sources.add("h1");
    else (name = og), sources.add("og");
  }
  if (!description && meta("og:description", "description")) (description = plain(meta("og:description", "description"))), sources.add("og");
  if (!imageUrl) {
    const og = absolute(meta("og:image:secure_url", "og:image", "twitter:image"));
    if (og) (imageUrl = og), sources.add("og");
  }

  // ---------- 4. last resorts ----------
  let nameFound = !!name;
  if (!name && h1 && h1.length <= LIMIT.name) (name = h1), (nameFound = true), sources.add("h1");
  if (!name) (name = plain(document.title)), sources.add("cim");
  if (!price) {
    // A visible price in an element that says it is one: "24 990 Ft".
    const pattern = /(\d{1,3}(?:[ .  ]\d{3})+|\d{3,})(?:,\d{1,2})?(?:,-)?\s*(?:Ft|HUF)\b/i;
    for (const el of document.querySelectorAll('[class*="price" i], [id*="price" i], [data-price], [class*="ar-" i]')) {
      const match = (el.textContent ?? "").match(pattern);
      if (match) {
        price = { value: match[0], currency: "HUF", source: "szoveg" };
        sources.add("szoveg");
        break;
      }
    }
  }

  // ---------- price: forints only ----------
  let priceHuf = null;
  let foreignCurrency = "";
  if (price) {
    const hungarianPage = /\.hu$/i.test(location.hostname) || /^hu\b/i.test(document.documentElement.lang || "");
    const currency = price.currency || (/ft|huf/i.test(String(price.value)) ? "HUF" : "");
    if (currency === "HUF" || (!currency && hungarianPage)) priceHuf = parsePrice(price.value);
    else if (currency) foreignCurrency = currency;
  }

  // ---------- product link: canonical, without tracking ----------
  const canonical = absolute(document.querySelector('link[rel="canonical"]')?.getAttribute("href"));
  let productUrl = canonical || absolute(meta("og:url")) || productUrlFromData || absolute(location.href);
  if (productUrl) {
    const url = new URL(productUrl);
    for (const key of [...url.searchParams.keys()]) if (TRACKING.test(key)) url.searchParams.delete(key);
    url.hash = "";
    productUrl = url.href;
  }

  // ---------- lengths ----------
  const clip = (text, max, ellipsis) => {
    if (text.length <= max) return text;
    const cut = text.slice(0, max - (ellipsis ? 1 : 0));
    const atWord = ellipsis ? cut.replace(/\s+\S*$/, "") : cut;
    return (atWord || cut).replace(/[\s,;:.-]+$/, "") + (ellipsis ? "…" : "");
  };
  name = clip(name, LIMIT.name, false);
  description = clip(description, LIMIT.description, true);
  if (description && description === name) description = "";

  const missing = [];
  if (!nameFound) missing.push("nev");
  // A price in another currency isn't an error: the popup says why it is empty.
  if (priceHuf === null && !foreignCurrency) missing.push("ar");
  if (!imageUrl) missing.push("kep");

  return { name, priceHuf, foreignCurrency, description, imageUrl, productUrl, missing, sources: [...sources] };
}

/**
 * The Surpriser link that opens a filled-in new plan (`#/uj-terv?…`, see the web's prefill.ts).
 * `hiba` (what the page didn't give), `forras` (where the data came from) and `v` are for the
 * error reports (milestone 1b); the editor ignores them.
 */
export function surpriserPlanUrl(fields, info) {
  const params = new URLSearchParams();
  const put = (key, value) => {
    const s = value == null ? "" : String(value).trim();
    if (s) params.set(key, s);
  };
  put("nev", fields.name);
  put("ar", fields.price);
  put("leiras", fields.description);
  put("kep", fields.imageUrl);
  put("link", fields.productUrl);
  if (info.missing && info.missing.length) params.set("hiba", info.missing.join(","));
  if (info.sources && info.sources.length) params.set("forras", info.sources.join(","));
  put("v", info.version);
  return "https://sengdev.com/apps/surpriser/#/uj-terv?" + params.toString();
}
