// Right click on an image → "Kép a Surpriserhez": the popup opens with that image.
// The chosen image waits in session storage (per tab, for that page) until the popup picks it up.

const MENU_ID = "surpriser-image";

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({ id: MENU_ID, title: "Kép a Surpriserhez", contexts: ["image"] });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== MENU_ID || !tab?.id) return;
  // Only web addresses can be saved (the rules require http(s)); data: and blob: images can't.
  const url = /^https?:\/\//i.test(info.srcUrl ?? "") && info.srcUrl.length <= 2000 ? info.srcUrl : "";
  const page = (info.pageUrl ?? tab.url ?? "").replace(/#.*$/, "");
  await chrome.storage.session.set({ [`pick:${tab.id}`]: { page, url } });
  try {
    await chrome.action.openPopup({ windowId: tab.windowId });
  } catch {
    // Older Chrome: no opening from here. A badge says the image is waiting; the icon opens the popup.
    await chrome.action.setBadgeBackgroundColor({ tabId: tab.id, color: "#6A4BD1" });
    await chrome.action.setBadgeText({ tabId: tab.id, text: "kép" });
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  chrome.storage.session.remove([`pick:${tabId}`, `draft:${tabId}`]);
});
