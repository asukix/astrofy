import { surpriserExtract, surpriserPlanUrl } from "../src/extract.js";

const $ = (id) => document.getElementById(id);
const VERSION = chrome.runtime.getManifest().version;
const LABEL = { nev: "név", ar: "ár", kep: "kép" };
const FIELDS = ["name", "price", "description", "imageUrl", "productUrl"];

/** The page address without "#…": a draft or a picked image belongs to one page. */
const pageOf = (url) => (url ?? "").replace(/#.*$/, "");

let tab = null;
/** What the page gave (for the error report in the link). */
let found = null;

const draftKey = () => `draft:${tab.id}`;
const pickKey = () => `pick:${tab.id}`;

function fill(fields) {
  for (const id of FIELDS) $(id).value = fields[id] ?? "";
  updatePreview();
  syncClear();
}

function fieldsOf(data) {
  return {
    name: data.name,
    price: data.priceHuf != null ? String(data.priceHuf) : "",
    description: data.description,
    imageUrl: data.imageUrl,
    productUrl: data.productUrl,
  };
}

function currentFields() {
  return Object.fromEntries(FIELDS.map((id) => [id, $(id).value]));
}

function showInfo(note) {
  $("currency").hidden = !found.foreignCurrency;
  $("currency").textContent = found.foreignCurrency ? `Az ár nem forintban van (${found.foreignCurrency}), ezért üresen hagytuk.` : "";
  const missing = found.missing.map((key) => LABEL[key]);
  $("missing").hidden = missing.length === 0;
  $("missing").textContent = missing.length ? `Ezt nem találtuk a lapon: ${missing.join(", ")}. Itt vagy a Surpriserben pótolhatod.` : "";
  $("state").textContent = note ?? "";
  $("state").hidden = !note;
  $("form").hidden = false;
}

function updatePreview() {
  const url = $("imageUrl").value.trim();
  const ok = /^https?:\/\/\S+$/i.test(url);
  $("preview").hidden = !ok;
  if (ok) $("previewImage").src = url;
}

/** The popup closes when the page is clicked (e.g. to pick another image): keep what was typed. */
function saveDraft() {
  if (!tab || !found) return;
  chrome.storage.session.set({ [draftKey()]: { page: pageOf(tab.url), found, fields: currentFields() } });
}

$("imageUrl").addEventListener("input", updatePreview);
$("previewImage").addEventListener("error", () => ($("preview").hidden = true));
for (const id of FIELDS) $(id).addEventListener("input", saveDraft);

// × in each field: empties it (for a wrong name, image…). Shown only while the field has text.
const clearButtons = [...document.querySelectorAll("button.clear")];
const syncClear = () => clearButtons.forEach((button) => (button.hidden = $(button.dataset.for).value === ""));
for (const button of clearButtons) {
  const field = $(button.dataset.for);
  field.addEventListener("input", syncClear);
  button.addEventListener("click", () => {
    field.value = "";
    field.dispatchEvent(new Event("input", { bubbles: true }));
    field.focus();
  });
}

$("reread").addEventListener("click", async () => {
  await chrome.storage.session.remove(draftKey());
  $("reread").hidden = true;
  await readPage();
  saveDraft();
});

$("form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const fields = currentFields();
  const url = surpriserPlanUrl(
    { ...fields, price: fields.price },
    { missing: found?.missing ?? [], sources: found?.sources ?? [], version: VERSION },
  );
  await chrome.storage.session.remove(draftKey());
  await openBeside(url);
  window.close();
});

/**
 * The Surpriser next to the shop, in split view (Chrome 155+: tabs.create with splitWithTabId), so the
 * product page stays in sight while saving. Older Chrome, Edge, or a tab already in a split: a new tab.
 */
async function openBeside(url) {
  const canSplit =
    tab && typeof chrome.tabs.createSplit === "function" && (tab.splitViewId ?? -1) === -1 && !tab.pinned;
  if (canSplit) {
    try {
      await chrome.tabs.create({ url, splitWithTabId: tab.id });
      return;
    } catch {
      /* not allowed here: fall back to a plain tab */
    }
  }
  await chrome.tabs.create({ url, index: tab ? tab.index + 1 : undefined });
}

/** Reads the open page and fills the form with it. */
async function readPage(note) {
  try {
    const [injection] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: surpriserExtract });
    if (!injection?.result) throw new Error("no result");
    found = injection.result;
  } catch {
    // chrome://, the Web Store, PDF viewer…: the browser doesn't let extensions read these pages.
    found = {
      name: (tab?.title ?? "").slice(0, 200),
      priceHuf: null,
      foreignCurrency: "",
      description: "",
      imageUrl: "",
      productUrl: /^https?:/i.test(tab?.url ?? "") ? pageOf(tab.url) : "",
      missing: ["nev", "ar", "kep"],
      sources: ["nincs"],
    };
    note = "Erről az oldalról a böngésző nem enged adatot kiolvasni. Kitöltheted kézzel is.";
  }
  fill(fieldsOf(found));
  showInfo(note);
}

async function start() {
  [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const page = pageOf(tab.url);
  const stored = await chrome.storage.session.get([draftKey(), pickKey()]);
  const draft = stored[draftKey()]?.page === page ? stored[draftKey()] : null;
  const pick = stored[pickKey()]?.page === page ? stored[pickKey()] : null;

  let note;
  if (draft) {
    found = draft.found;
    fill(draft.fields);
    $("reread").hidden = false;
  } else {
    await readPage();
    note = $("state").hidden ? undefined : $("state").textContent;
  }

  // An image chosen with right click → "Kép a Surpriserhez".
  if (pick) {
    await chrome.storage.session.remove(pickKey());
    chrome.action.setBadgeText({ tabId: tab.id, text: "" });
    if (pick.url) {
      $("imageUrl").value = pick.url;
      updatePreview();
      syncClear();
      note = "A jobb klikkel kiválasztott képet tettük be.";
    } else {
      note = "Ezt a képet nem lehet linkként menteni (nem webcímről jön). Válassz másikat, vagy írd be a linkjét.";
    }
  }
  showInfo(note);
  saveDraft();
  $("name").focus();
}

start();
